import clr, unittest, sys

class TestermaticTestCase(unittest.TestCase):
    def __init__(self, testcase):
        self._listeners = []
        self._testcase = testcase

    def addListener(self, listener):
        if listener:
            self._listeners.append(listener)
            
    def setUp(self):
        self._testcase.setUp()
        
    def tearDown(self):
        self._testcase.tearDown()
        
    def countTestCases(self):
        return self._testcase.countTestCases()

    def shortDescription(self):
        return self._testcase.shortDescription()
        
    def id(self):
        return self._testcase.id()
        
    def __str__(self):
        return self._testcase.__str__
        
    def __repr__(self):
        return self._testcase.__repr__
        
    def run(self, result=None):
        self._testcase.run(result)
        if result:
            for listener in self._listeners:
                listener(self, result.testsRun, result.failures, result.errors)
        return result
        


def getTests(prefix='test'):
    """ Finds all tests in all loaded modules, except for certain predefined modules """
    tests = []
    for mod_name in sys.modules:
        if not mod_name in ['unittest', 'testermatic', 'clr', 'unittest.case']:
#            print 'mod_name = %s' % mod_name
            testsuites = unittest.findTestCases(sys.modules[mod_name], prefix)
            if testsuites:
                for testsuite in testsuites:
                    for test in testsuite:
                        tests.append(test)	
    return tests
    

def runTests(test_list, complete_func=None):
    suite = unittest.TestSuite()
    for test in test_list:
        print test
        if complete_func:
            test = TestermaticTestCase(test)
            test.addListener(complete_func)			
        suite.addTest(test)	
    
    return unittest.TextTestRunner().run(suite)
