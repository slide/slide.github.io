using System;
using System.Net.Mail;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Testermatic {
    public partial class EmailForm : Form {
        private string _output;

        public EmailForm(string output) {
            InitializeComponent();

            _output = output;
        }

        private void cancel_Click(object sender, EventArgs e) {
            Close();
        }

        private void send_Click(object sender, EventArgs e) {
            if (string.IsNullOrEmpty(to.Text) || string.IsNullOrEmpty(from.Text)) {
                MessageBox.Show(this,
                    "You must provide to and from addresses", "Invalid to/from");
            } else {
                SmtpClient client = new SmtpClient();
                MailMessage msg = new MailMessage();
                msg.To.Add(new MailAddress(to.Text));
                msg.To.Add(new MailAddress(from.Text));
                msg.From = new MailAddress(from.Text);
                msg.Subject = string.Format("{0} - Testermatic Results", Environment.MachineName);
                msg.IsBodyHtml = true;

                string body = "<html><head><style type=\"text/css\">body { font-family: Courier; font-size: 10pt }</style><body>";
                body += Parse(message.Text + Environment.NewLine + Environment.NewLine + _output);
                body += "</body></html>";
                msg.Body = body;

                client.Send(msg);

                MessageBox.Show(this, "Mail sent", "Mail Sent");
                Close();
            }
        }

        private string Parse(string input) {
            Regex error_re = new Regex(@"=+\r*\n\w*ERROR:\w*([^\r\n]*)\r*\n-+",
                RegexOptions.Compiled | RegexOptions.Multiline);

            Match match = error_re.Match(input);

            while (match.Success) {
                input = input.Replace(match.Value, "<span style=\"font-weight: bold\">" + match.Value + "</span>");
                match = match.NextMatch();
            }

            input = input.Replace("\n", "<br/ >\n");
            input = input.Replace(" ", "&nbsp;");
            input = input.Replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
            return input;
        }
    }
}