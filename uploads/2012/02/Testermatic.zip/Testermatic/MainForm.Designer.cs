namespace Testermatic
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.main_statusbar = new System.Windows.Forms.StatusStrip();
            this.main_menu = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exit_menu_item = new System.Windows.Forms.ToolStripMenuItem();
            this.main_toolbar = new System.Windows.Forms.ToolStrip();
            this.open_button = new System.Windows.Forms.ToolStripButton();
            this.start_tests = new System.Windows.Forms.ToolStripButton();
            this.reload = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.email = new System.Windows.Forms.ToolStripButton();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.test_list = new System.Windows.Forms.ListView();
            this.test_header = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.output = new System.Windows.Forms.RichTextBox();
            this.main_menu.SuspendLayout();
            this.main_toolbar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // main_statusbar
            // 
            this.main_statusbar.Location = new System.Drawing.Point(0, 669);
            this.main_statusbar.Name = "main_statusbar";
            this.main_statusbar.Size = new System.Drawing.Size(891, 22);
            this.main_statusbar.TabIndex = 1;
            this.main_statusbar.Text = "statusStrip1";
            // 
            // main_menu
            // 
            this.main_menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.main_menu.Location = new System.Drawing.Point(0, 0);
            this.main_menu.Name = "main_menu";
            this.main_menu.Size = new System.Drawing.Size(891, 24);
            this.main_menu.TabIndex = 2;
            this.main_menu.Text = "mainmenu";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exit_menu_item});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // exit_menu_item
            // 
            this.exit_menu_item.Name = "exit_menu_item";
            this.exit_menu_item.Size = new System.Drawing.Size(92, 22);
            this.exit_menu_item.Text = "E&xit";
            this.exit_menu_item.Click += new System.EventHandler(this.exit_menu_item_Click);
            // 
            // main_toolbar
            // 
            this.main_toolbar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.open_button,
            this.start_tests,
            this.reload,
            this.toolStripSeparator1,
            this.email});
            this.main_toolbar.Location = new System.Drawing.Point(0, 24);
            this.main_toolbar.Name = "main_toolbar";
            this.main_toolbar.Size = new System.Drawing.Size(891, 25);
            this.main_toolbar.TabIndex = 3;
            this.main_toolbar.Text = "maintoolbar";
            // 
            // open_button
            // 
            this.open_button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.open_button.Image = ((System.Drawing.Image)(resources.GetObject("open_button.Image")));
            this.open_button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.open_button.Name = "open_button";
            this.open_button.Size = new System.Drawing.Size(23, 22);
            this.open_button.Text = "toolStripButton1";
            this.open_button.Click += new System.EventHandler(this.open_button_Click);
            // 
            // start_tests
            // 
            this.start_tests.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.start_tests.Image = ((System.Drawing.Image)(resources.GetObject("start_tests.Image")));
            this.start_tests.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.start_tests.Name = "start_tests";
            this.start_tests.Size = new System.Drawing.Size(23, 22);
            this.start_tests.Text = "Run tests";
            this.start_tests.Click += new System.EventHandler(this.start_tests_Click);
            // 
            // reload
            // 
            this.reload.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.reload.Image = ((System.Drawing.Image)(resources.GetObject("reload.Image")));
            this.reload.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.reload.Name = "reload";
            this.reload.Size = new System.Drawing.Size(23, 22);
            this.reload.Text = "Reload tests";
            this.reload.Click += new System.EventHandler(this.reload_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // email
            // 
            this.email.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.email.Image = ((System.Drawing.Image)(resources.GetObject("email.Image")));
            this.email.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(23, 22);
            this.email.Text = "Email Report";
            this.email.Click += new System.EventHandler(this.email_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 49);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.test_list);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.output);
            this.splitContainer1.Size = new System.Drawing.Size(891, 620);
            this.splitContainer1.SplitterDistance = 270;
            this.splitContainer1.TabIndex = 4;
            // 
            // test_list
            // 
            this.test_list.CheckBoxes = true;
            this.test_list.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.test_header});
            this.test_list.Dock = System.Windows.Forms.DockStyle.Fill;
            this.test_list.FullRowSelect = true;
            this.test_list.Location = new System.Drawing.Point(0, 0);
            this.test_list.Name = "test_list";
            this.test_list.Size = new System.Drawing.Size(270, 620);
            this.test_list.TabIndex = 2;
            this.test_list.UseCompatibleStateImageBehavior = false;
            this.test_list.View = System.Windows.Forms.View.Details;
            // 
            // test_header
            // 
            this.test_header.Text = "Test";
            // 
            // output
            // 
            this.output.BackColor = System.Drawing.SystemColors.Window;
            this.output.DetectUrls = false;
            this.output.Dock = System.Windows.Forms.DockStyle.Fill;
            this.output.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.output.Location = new System.Drawing.Point(0, 0);
            this.output.Name = "output";
            this.output.ReadOnly = true;
            this.output.Size = new System.Drawing.Size(617, 620);
            this.output.TabIndex = 0;
            this.output.Text = "";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(891, 691);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.main_toolbar);
            this.Controls.Add(this.main_statusbar);
            this.Controls.Add(this.main_menu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.main_menu;
            this.Name = "MainForm";
            this.Text = "Testermatic";
            this.main_menu.ResumeLayout(false);
            this.main_menu.PerformLayout();
            this.main_toolbar.ResumeLayout(false);
            this.main_toolbar.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip main_statusbar;
        private System.Windows.Forms.MenuStrip main_menu;
        private System.Windows.Forms.ToolStrip main_toolbar;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.RichTextBox output;
        private System.Windows.Forms.ToolStripButton open_button;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exit_menu_item;
        private System.Windows.Forms.ToolStripButton start_tests;
        private System.Windows.Forms.ListView test_list;
        private System.Windows.Forms.ColumnHeader test_header;
        private System.Windows.Forms.ToolStripButton reload;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton email;
    }
}

