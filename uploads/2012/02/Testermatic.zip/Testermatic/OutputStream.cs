using System;
using System.IO;
using System.Text;

namespace Testermatic {
    class OutputStream : MemoryStream {
        public class OutputEventArgs : EventArgs {
            public OutputEventArgs(string text) {
                Text = text;
            }

            public string Text {
                get;
                private set;
            }
        }

        public event EventHandler<OutputEventArgs> Output;

        public OutputStream()
            : base() {
        }

        public override void Write(byte[] buffer, int offset, int count) {
            string result = Encoding.ASCII.GetString(buffer, offset, count);
            if (!string.IsNullOrEmpty(result))
                OnOutput(result);
        }        

        public void WriteLine(string format, params object[] args) {
            string result = string.Format(format, args);
            if (!result.EndsWith("\n"))
                result = result + "\n";

            if (!string.IsNullOrEmpty(result))
                OnOutput(result);
        }

        void OnOutput(string text) {
            if (Output != null)
                Output(this, new OutputEventArgs(text));
        }
    }
}
