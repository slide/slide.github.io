using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace Testermatic
{
    static class Win32
    {
        // Win32 API Function Prototypes
        [DllImport("user32", SetLastError = true, EntryPoint = "SendMessageW")]
        public static extern int SendMessage(HandleRef hwnd, int message, int wParam, int lParam);

        [DllImport("user32", SetLastError = true, EntryPoint = "PostMessageW")]
        public static extern int PostMessage(HandleRef hwnd, int message, int wParam, int lParam);

        [DllImport("user32", SetLastError = true, EntryPoint = "PostMessageW")]
        public static extern int PostMessage(HandleRef hwnd, int message, string wParam, int lParam);

        [DllImport("user32", SetLastError = true, EntryPoint = "SendMessageW")]
        public static extern int SendMessage(HandleRef hwnd, int message, string wParam, int lParam);

        [DllImport("kernel32", SetLastError = true)]
        public static extern IntPtr GetConsoleWindow();

        [DllImport("user32", SetLastError = true)]
        public static extern bool ShowWindow(IntPtr hWnd, int nShowCmd);

        [DllImport("kernel32", SetLastError = true)]
        public static extern bool SetConsoleTitle(string lpConsoleTitle);

        [DllImport("user32", SetLastError = true)]
        public static extern bool IsWindowVisible(IntPtr hWnd);


        public const int SW_HIDE = 0;
        public const int SW_SHOW = 5;
        public const int SW_NOACTIVATE = 16;
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Win32 Constants
        public const int WM_VSCROLL = 0x115;

        public const int MB_SETFOREGROUND = 0x00010000;

        // Edit Control Messages
        public const int EM_GETSEL = 0xB0;
        public const int EM_SETSEL = 0xB1;
        public const int EM_GETRECT = 0xB2;
        public const int EM_SETRECT = 0xB3;
        public const int EM_SETRECTNP = 0xB4;
        public const int EM_SCROLL = 0xB5;
        public const int EM_LINESCROLL = 0xB6;
        public const int EM_SCROLLCARET = 0xB7;
        public const int EM_GETMODIFY = 0xB8;
        public const int EM_SETMODIFY = 0xB9;
        public const int EM_GETLINECOUNT = 0xBA;
        public const int EM_LINEINDEX = 0xBB;
        public const int EM_SETHANDLE = 0xBC;
        public const int EM_GETHANDLE = 0xBD;
        public const int EM_GETTHUMB = 0xBE;
        public const int EM_LINELENGTH = 0xC1;
        public const int EM_REPLACESEL = 0xC2;
        public const int EM_GETLINE = 0xC4;
        public const int EM_LIMITTEXT = 0xC5;
        public const int EM_CANUNDO = 0xC6;
        public const int EM_UNDO = 0xC7;
        public const int EM_FMTLINES = 0xC8;
        public const int EM_LINEFROMCHAR = 0xC9;
        public const int EM_SETTABSTOPS = 0xCB;
        public const int EM_SETPASSWORDCHAR = 0xCC;
        public const int EM_EMPTYUNDOBUFFER = 0xCD;
        public const int EM_GETFIRSTVISIBLELINE = 0xCE;
        public const int EM_SETREADONLY = 0xCF;
        public const int EM_SETWORDBREAKPROC = 0xD0;
        public const int EM_GETWORDBREAKPROC = 0xD1;
        public const int EM_GETPASSWORDCHAR = 0xD2;
        public const int EM_SETMARGINS = 0xD3;
        public const int EM_GETMARGINS = 0xD4;
        public const int EM_SETLIMITTEXT = EM_LIMITTEXT; //win40 Name change
        public const int EM_GETLIMITTEXT = 0xD5;
        public const int EM_POSFROMCHAR = 0xD6;
        public const int EM_CHARFROMPOS = 0xD7;
        public const int EM_SETIMESTATUS = 0xD8;
        public const int EM_GETIMESTATUS = 0xD9;
        public const int SC_CLOSE = 0xF060;
        public const int SB_BOTTOM = 7;
    }
}
