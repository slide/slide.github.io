using System;
using System.IO;
using System.Data;
using System.Text;
using System.Drawing;
using System.Threading;
using System.Resources;
using System.Reflection;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;
using System.Runtime.InteropServices;

using Microsoft.Scripting.Hosting;
using IronPython.Hosting;
using IronPython.Runtime;
using IronPython.Runtime.Exceptions;

namespace Testermatic {
    public partial class MainForm : Form {
        readonly string PYTHON_DIR;

        ScriptScope _scope;
        ScriptEngine _engine;

        OutputStream _stdout;
        OutputStream _stderr;
        string _current_test_file;

        public MainForm() {
            InitializeComponent();

            PYTHON_DIR = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);

            test_list.Columns[0].Width = test_list.Width - 5;
        }

        #region Event Handlers

        private void stderr_Output(object sender, OutputStream.OutputEventArgs e) {
            output.BeginInvoke((MethodInvoker)delegate {
                output.AppendText(e.Text);
                Win32.PostMessage(new HandleRef(output, output.Handle), Win32.WM_VSCROLL, Win32.SB_BOTTOM, 0);
            });
            Console.WriteLine(e.Text);
        }

        private void stdout_Output(object sender, OutputStream.OutputEventArgs e) {
            output.BeginInvoke((MethodInvoker)delegate {
                output.AppendText(e.Text);
                Win32.PostMessage(new HandleRef(output, output.Handle), Win32.WM_VSCROLL, Win32.SB_BOTTOM, 0);
            });
            Console.WriteLine(e.Text);
        }

        #endregion

        #region Event Overloads

        protected override void OnLoad(EventArgs e) {
            base.OnLoad(e);

            if (string.IsNullOrEmpty(PYTHON_DIR)) {
                MessageBox.Show(this, "Could not find Python installation, please install Python from http://www.python.org", "Missing Python Installation",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
            } else {
                //if (!string.IsNullOrEmpty(Boardom.Properties.Settings.Default.LastFile) && File.Exists(Boardom.Properties.Settings.Default.LastFile))
                //   LoadTests(Boardom.Properties.Settings.Default.LastFile);
            }
        }       

        #endregion

        private void InitializeEngine() {
            // first clear out anything we have now
            if (_scope != null)
                _scope = null;

            if (_engine != null)
                _engine = null;

            _engine = Python.CreateEngine();
            _scope = _engine.CreateScope();

            _stdout = new OutputStream();
            _stderr = new OutputStream();
            _stdout.Output += stdout_Output;
            _stderr.Output += stderr_Output;

            _engine.Runtime.IO.SetOutput(_stdout, Encoding.ASCII);
            _engine.Runtime.IO.SetErrorOutput(_stderr, Encoding.ASCII);

            // add the local python installation libs
            ICollection<string> searchPaths = _engine.GetSearchPaths();
            searchPaths.Add(Path.Combine(PYTHON_DIR, "Lib"));
            searchPaths.Add(Path.Combine(Path.Combine(PYTHON_DIR, "Lib"), "site-packages"));
            searchPaths.Add(Path.GetDirectoryName(GetType().Assembly.Location));

            _engine.SetSearchPaths(searchPaths);

            // import some default stuff.
            Import("sys", "os", "unittest", "testermatic");
            _stdout.WriteLine("Ready...");
        }

        private void open_button_Click(object sender, EventArgs e) {
            OpenFileDialog open_dlg = new OpenFileDialog();
            open_dlg.CheckPathExists = true;
            open_dlg.DefaultExt = ".py";
            open_dlg.Filter = "Python Scripts (*.py)|*.py|All Files (*.*)|*.*";
            open_dlg.FilterIndex = 0;
            open_dlg.Multiselect = false;
            open_dlg.RestoreDirectory = true;
            open_dlg.SupportMultiDottedExtensions = true;
            open_dlg.Title = "Open Python Test Script";
            open_dlg.ValidateNames = true;

            if (open_dlg.ShowDialog(this) == DialogResult.OK) {
                Thread thread = new Thread(new ParameterizedThreadStart(LoadTests));
                thread.IsBackground = true;
                thread.Start(open_dlg.FileName);
            }
        }

        private void Import(params string[] module_names) {
            foreach (string module_name in module_names) {
                _stdout.WriteLine("importing {0}...", module_name);
                try {
                    _scope.SetVariable(module_name, _engine.ImportModule(module_name));
                } catch (ImportException ex) {
                    _stdout.WriteLine("Could not import {0} - {1}", module_name, ex.Message);
                } catch (Exception ex) {
                    _stdout.WriteLine("Exception importing {0} - {1}", module_name, ex.Message);
                }
            }
        }

        void LoadTests(object file) {
            LoadTests((string)file);
        }

        /// <summary>
        /// Imports the file and then searches for tests within loaded modules.
        /// </summary>
        /// <param name="file">The file to import</param>
        private void LoadTests(string file) {
            InitializeEngine();

            ICollection<string> searchPaths = _engine.GetSearchPaths();
            searchPaths.Add(Path.GetDirectoryName(file));

            _engine.SetSearchPaths(searchPaths);
            string module_name = Path.GetFileNameWithoutExtension(file);
            Import(module_name);

            List tests = _engine.Execute<List>("testermatic.getTests()", _scope);

            // we autoselect the tests that appear in the selected list, if they are here
            test_list.Items.Clear();
            foreach (dynamic test in tests) {
                string testName = test.id();
                Invoke((Action)delegate() {
                    ListViewItem new_item = test_list.Items.Add(testName);
                    new_item.Checked = true;
                    new_item.Tag = test;
                });
            }

            _current_test_file = file;
            _stdout.WriteLine("Ready...");
        }

        private void exit_menu_item_Click(object sender, EventArgs e) {
            Close();
        }

        private void start_tests_Click(object sender, EventArgs e) {
            if (test_list.CheckedItems.Count == 0)
                MessageBox.Show(this, "You must select tests to run", "No tests selected", MessageBoxButtons.OK);
            else {
                output.Clear();

                foreach (ListViewItem item in test_list.Items)
                    item.ForeColor = Color.Black;

                List tests = new List();
                foreach (ListViewItem item in test_list.CheckedItems)
                    tests.Add(item.Tag);

                System.Threading.Thread thread = new System.Threading.Thread(RunTests);
                thread.IsBackground = true;
                thread.Start(tests);
            }
        }

        /// <summary>
        /// Runs the tests in the given test list.
        /// </summary>
        /// <param name="test_list"></param>
        private void RunTests(object test_list) {
            try {
                if (test_list is List) {
                    // call our utility method to run the selected tests
                    ScriptScope testermatic = null;
                    dynamic runTests = null;

                    if (_scope.TryGetVariable("testermatic", out testermatic) &&
                        testermatic.TryGetVariable("runTests", out runTests)) {
                        runTests(test_list, new TestsCompleteDelegate(TestsComplete));
                    }
                } else {
                    _stdout.WriteLine("Test list was not correct type!");
                }
            } catch (Exception ex) {
                _stderr.WriteLine("Error running tests - {0}", ex.ToString());
            }
        }

        private delegate object TestsCompleteDelegate(object sender, int num_tests, List failures, List errors);
        private object TestsComplete(object sender, int num_tests, List failures, List errors) {
            if (InvokeRequired) {
                return Invoke(new TestsCompleteDelegate(TestsComplete), sender, num_tests, failures, errors);
            } else {
                Dictionary<string, object> locals = new Dictionary<string, object>();
                List<int> failed_indices = new List<int>();

                // failures occur when an assertion of some sort fails.
                if (failures.Count > 0) {
                    foreach (PythonTuple item in failures) {
                        foreach (ListViewItem test_list_item in test_list.CheckedItems) {
                            dynamic test_list_tag = test_list_item.Tag;
                            string tag_id = test_list_tag.id();

                            dynamic test_item = item[0];
                            string test_id = test_item.id();
                            if (string.Compare(test_id, tag_id, true) == 0) {
                                failed_indices.Add(test_list_item.Index);
                                test_list_item.ForeColor = Color.Red;
                            }
                        }
                    }
                }

                // errors occur when something isn't correct in the code
                if (errors.Count > 0) {
                    foreach (PythonTuple item in errors) {
                        foreach (ListViewItem test_list_item in test_list.CheckedItems) {
                            dynamic test_list_tag = test_list_item.Tag;
                            string tag_id = test_list_tag.id();

                            dynamic test_item = item[0];
                            string test_id = test_item.id();
                            if (string.Compare(test_id, tag_id, true) == 0) {
                                failed_indices.Add(test_list_item.Index);
                                test_list_item.ForeColor = Color.Purple;
                            }
                        }
                    }
                }

                // set other items to passed if they didn't fail, or error
                foreach (ListViewItem item in test_list.CheckedItems) {
                    if (!failed_indices.Contains(item.Index) && item.Checked)
                        item.ForeColor = Color.DarkGreen;
                }
                return null;
            }
        }

        private void reload_Click(object sender, EventArgs e) {
            LoadTests(_current_test_file);
        }

        private void email_Click(object sender, EventArgs e) {
            EmailForm form = new EmailForm(output.Text);
            form.ShowDialog();
        }
    }
}